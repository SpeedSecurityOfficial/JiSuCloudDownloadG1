@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

echo ========================================
echo     证书自动安装脚本
echo ========================================
echo.

:: 检查是否以管理员权限运行
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [错误] 请以管理员身份运行此脚本！
    echo 右键点击脚本，选择"以管理员身份运行"
    pause
    exit /b 1
)

:: 获取脚本所在目录
set "SCRIPT_DIR=%~dp0"
set "SCRIPT_DIR=%SCRIPT_DIR:~0,-1%"

:: 定义证书目录
set "ROOT_DIR=%SCRIPT_DIR%\CA\Root"
set "MIDDLE_DIR=%SCRIPT_DIR%\CA\middle"
set "CROSS_DIR=%SCRIPT_DIR%\CA\cross"

:: 安装根证书
echo [1/3] 安装根证书...
if exist "%ROOT_DIR%" (
    call :InstallCertificates "%ROOT_DIR%" "Root" "Root"
) else (
    echo   [跳过] 目录不存在: %ROOT_DIR%
)
echo.

:: 安装中间证书
echo [2/3] 安装中间证书...
if exist "%MIDDLE_DIR%" (
    call :InstallCertificates "%MIDDLE_DIR%" "Middle" "CA"
) else (
    echo   [跳过] 目录不存在: %MIDDLE_DIR%
)
echo.

:: 安装交叉证书
echo [3/3] 安装交叉证书...
if exist "%CROSS_DIR%" (
    call :InstallCertificates "%CROSS_DIR%" "Cross" "CA"
) else (
    echo   [跳过] 目录不存在: %CROSS_DIR%
)
echo.

echo ========================================
echo     证书安装完成！
echo ========================================
pause
exit /b 0

::==========================================
:: 函数：安装证书
:: 参数：%1 = 证书目录路径
::       %2 = 证书类型名称（用于显示）
::       %3 = 存储区名称（Root 或 CA）
::==========================================
:InstallCertificates
set "CERT_DIR=%~1"
set "CERT_TYPE=%~2"
set "STORE_NAME=%~3"
set "SUCCESS_COUNT=0"
set "FAIL_COUNT=0"

echo   正在安装 %CERT_TYPE% 证书...
pushd "%CERT_DIR%" 2>nul

for %%f in (*.crt) do (
    set "CERT_FILE=%%f"
    echo     处理证书: %%f
    
    :: 使用 certutil 安装证书
    if "%STORE_NAME%"=="Root" (
        certutil -addstore "Root" "%%f" >nul 2>&1
    ) else (
        certutil -addstore "CA" "%%f" >nul 2>&1
    )
    
    if !errorlevel! equ 0 (
        echo       [成功] 已安装
        set /a SUCCESS_COUNT+=1
    ) else (
        echo       [失败] 安装失败，可能证书已存在或格式错误
        set /a FAIL_COUNT+=1
    )
)

popd

echo   安装完成: 成功 !SUCCESS_COUNT! 个, 失败 !FAIL_COUNT! 个
goto :eof